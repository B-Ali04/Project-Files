SHRLGPA.SHRLGPA_GPA >= 3.750000

and SGBSTDN.SGBSTDN_LEVL_CODE = 'UG'
and STVCLAS.STVCLAS_CODE = 'SO'

and not exists(
        select *

        from
        SGRSATT SGRSATT

        where
        SGRSATT.SGRSATT_PIDM = SPRIDEN.SPRIDEN_PIDM
        and SGRSATT.SGRSATT_TERM_CODE_EFF = STVTERM.STVTERM_CODE
        and SGRSATT.SGRSATT_ATTS_CODE in ('LHON','UHON', 'HONR')
    )