select 
    RCRAPP2_C_PAR_1_AGI_TAX_INC Household_Income,
    SRVYSTU.SRVYSTU_RACE_CODE Race_Ethnicity,
    SRVYSTU.SRVYSTU_RACE_DESC Race_Desc,
    SRVYSTU.SRVYSTU_GENDER Gender,
    substr(SPRADDR.SPRADDR_ZIP,1,5) Zip_Code,
--    SRVYSTU_SAT_COMBINED SAT_Composite,
    (select sum(SORTEST.SORTEST_TEST_SCORE)
    from SORTEST SORTEST
    where SORTEST.SORTEST_PIDM = SRVYSTU.SRVYSTU_PIDM
    and SORTEST.SORTEST_TESC_CODE in ('S05')
        ) SATCompositeScore,    
/*
    (select sum(SORTEST.SORTEST_TEST_SCORE)
    from SORTEST SORTEST --WHERE SORTEST.SORTEST_TESC_CODE LIKE 'S%%' SELECT * FROM STVTESC order by stvtesc_code
    where SORTEST.SORTEST_PIDM = SRVYSTU.SRVYSTU_PIDM
    and SORTEST.SORTEST_TESC_CODE in ('A05')
        ) ACTCompositeScore,  
*/          
    SRVYSTU_ACT_COMPOSITE ACT_Composite
    
from

    SRVYSTU SRVYSTU
    
    join STVTERM STVTERM on STVTERM.STVTERM_CODE = 201920

    left outer join SPRADDR SPRADDR on SPRADDR.SPRADDR_PIDM = SRVYSTU.SRVYSTU_PIDM
        and SPRADDR.SPRADDR_ATYP_CODE in ('PR')
        and SPRADDR.SPRADDR_STATUS_IND is null
        and SPRADDR.SPRADDR_VERSION = (
            select max(SPRADDR_VERSION)
            from SPRADDR SPRADDR1
            where SPRADDR1.SPRADDR_PIDM = SPRADDR.SPRADDR_PIDM
            and SPRADDR1.SPRADDR_ATYP_CODE in ('PR')
            and SPRADDR1.SPRADDR_STATUS_IND is null)
        and SPRADDR.SPRADDR_SURROGATE_ID = (
            select max(SPRADDR_SURROGATE_ID)
            from SPRADDR SPRADDR1
            where SPRADDR1.SPRADDR_PIDM = SPRADDR.SPRADDR_PIDM
            and SPRADDR1.SPRADDR_ATYP_CODE in ('PR')
            and SPRADDR1.SPRADDR_STATUS_IND is null)  
            
    left outer join RCRAPP2 RCRAPP2 on RCRAPP2.RCRAPP2_PIDM = SRVYSTU.SRVYSTU_PIDM
        and RCRAPP2.RCRAPP2_AIDY_CODE = STVTERM.STVTERM_FA_PROC_YR
        and RCRAPP2.RCRAPP2_INFC_CODE = 'EDE'
        and RCRAPP2.RCRAPP2_SEQ_NO = (
           select max(RCRAPP2_SEQ_NO)
           from RCRAPP2 r
           where r.RCRAPP2_PIDM = SRVYSTU.SRVYSTU_PIDM
           and r.RCRAPP2_AIDY_CODE = STVTERM.STVTERM_FA_PROC_YR
        )            
                    
where
    SRVYSTU_TERM_CODE = STVTERM.STVTERM_CODE
    and SRVYSTU.SRVYSTU_STATUS_CODE = 'AS'
    and SRVYSTU.SRVYSTU_LEVEL_CODE = 'UG'
--    and SRVYSTU.SRVYSTU_TYPE_CODE not in ('X')
    and SRVYSTU.SRVYSTU_TYPE_CODE in ('F')    
    and SRVYSTU.SRVYSTU_PRETERM_CLASS_YR_CODE not in ('BG')
    and SRVYSTU.SRVYSTU_POSTERM_CLASS_YR_CODE not in ('BG')
    and SRVYSTU.SRVYSTU_CURRIC_1_MAJOR_CODE not in ('UNDC', 'SUS', 'VIS', '0000', 'EHS')        
    
order by 
    SRVYSTU_ACT_COMPOSITE desc, RCRAPP2_C_PAR_1_AGI_TAX_INC desc